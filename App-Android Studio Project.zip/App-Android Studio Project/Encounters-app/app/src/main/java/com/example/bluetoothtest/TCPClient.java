package com.example.bluetoothtest;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class TCPClient implements Runnable {

    private final String SERVER_IP = "192.168.1.69";
    private final int SERVER_PORT = 6789;

    private String data;
    private String serverFeedback;


    public TCPClient() {
        serverFeedback = "ERROR";
    }

    public String sendServer(String data){
        this.data = data;
        Thread t = new Thread(this);
        t.start();
        int enableTimeOut = 10;
        while(serverFeedback.equals("ERROR") && enableTimeOut-- > 0) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
            }
        }
        return serverFeedback;
    }

    public void run(){
        try {
            // Initiate contact
            Socket clientSocket;

            clientSocket = new Socket(SERVER_IP, SERVER_PORT);

            // Create I/O Streams
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // Process the connection
            outToServer.writeBytes(data + "\n");
            serverFeedback = inFromServer.readLine();

            //Terminate Connection
            clientSocket.close();
            outToServer.close();
            inFromServer.close();

        } catch (IOException e) {
            serverFeedback = "ERROR";
        }
    }

}
