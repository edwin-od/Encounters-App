package com.example.bluetoothtest;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private final long RESET_DELAY_MILLISECONDS = 10000;
    private final long UPDATE_DELAY_MILLISECONDS = 5000;

    private Button powerBT;

    private boolean isStarted = false;

    public BluetoothAdapter BA;

    public static final String TAG = "MainActivity";

    public Context con;

    private final int RSSI_THRESHOLD = -80;

    private String ID;

    private ArrayList<String> encounters;

    private TextView login_error;
    private TextView register_error;

    private SharedPreferences sp;

    public BroadcastReceiver BRPower = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)){
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);

                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(TAG, "BRPower: STATE OFF");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(TAG, "BRPower: STATE TURNING OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(TAG, "BRPower: STATE ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(TAG, "BRPower: STATE TURNING ON");
                        break;
                }
            }
        }
    };
    public BroadcastReceiver BRVisible = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED.equals(action)){
                final int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);

                switch(mode){
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(TAG, "BRVisible: Discoverability Enabled");
                        break;
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(TAG, "BRVisible: Discoverability Disabled. Able to Receive Connections!");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(TAG, "BRVisible: Discoverability Disabled. Unable to Receive Connections!");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(TAG, "BRVisible: Connecting..");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(TAG, "BRVisible: Connected");
                        break;
                }
            }
        }
    };

    private BroadcastReceiver BRScan = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "BRScan: ACTION FOUND");

            if (action.equals(BluetoothDevice.ACTION_FOUND)){
                BluetoothDevice device = intent.getParcelableExtra (BluetoothDevice.EXTRA_DEVICE);
                if(device == null)
                    return;
                int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
                String devName = device.getName();
                if(devName == null || devName.equals("null"))
                    return;
                Log.d(TAG, "BRScan: \"" + devName + "\" : " + rssi + "dBm");

                if(rssi > RSSI_THRESHOLD){
                    String[] deviceNameInfo = devName.split("_");
                    if(deviceNameInfo.length < 2){
                        Log.d(TAG, "BRScan: Device Name \"" + device.getName() + "\" Is Of The Wrong Format!");
                        return;
                    }
                    try {
                        Integer.parseInt(deviceNameInfo[1]);
                    } catch(NumberFormatException e){
                        Log.d(TAG, "BRScan: Device Name \"" + device.getName() + "\" Is Of The Wrong Format!");
                        return;
                    }
                    if(deviceNameInfo[0].equals("Covid-19 Tracer")){
                        boolean registered = registerEncounter(deviceNameInfo[1]);
                        if(!registered){
                            Log.d(TAG, "Register_Encounter: Could Not Register Encounter! User \"" + deviceNameInfo[1]
                                    + "\" Might Not Be In Our Database");
                        }
                    } else {
                        Log.d(TAG, "BRScan: Device Name \"" + device.getName() + "\" Is Of The Wrong Format!");
                    }
                } else {
                    Log.d(TAG, "BRScan: Device \"" + device.getName() + "\" Is Out Of Range, RSSI= " + rssi + "dBm");
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BA = BluetoothAdapter.getDefaultAdapter();

        encounters = new ArrayList<>();

        sp = getSharedPreferences("phoneNB_SP", Context.MODE_PRIVATE);

        if(getSavedPhoneNumber() != null && fetchUserData()){
            startMainActivity();
        }else{
            startLoginActivity();
        }

        con = this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy: CALLED");
        unregisterReceiver(BRPower);
        unregisterReceiver(BRVisible);
        unregisterReceiver(BRScan);
    }

    public void powerBluetooth(){
        if (BA == null){
            Log.d(TAG, "powerBT: Device Does Not Support Bluetooth");
            powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.startButton));
            isStarted = false;
            return;
        }
        if(!isStarted){
            if(!BA.isEnabled()) {
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableIntent);

                IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
                registerReceiver(BRPower, BTIntent);
            }
            int enableTimeOut = 10;
            while(!BA.isEnabled() && enableTimeOut-- > 0) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                }
            }
            if(!BA.isEnabled()){
                powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.startButton));
                isStarted = false;
                ToastMain("Could not start service!", Toast.LENGTH_SHORT);
                return;
            }
            startVisibility();
            enableTimeOut = 10;
            while(BA.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE && enableTimeOut-- > 0) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                }
            }
            if(BA.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE){
                powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.startButton));
                BA.disable();
                isStarted = false;
                ToastMain("Could not start service!", Toast.LENGTH_SHORT);
                return;
            }
            BA.setName("Covid-19 Tracer_" + ID);
            powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.stopButton));
            resetLoop();
            isStarted = true;
            ToastMain("Service Started", Toast.LENGTH_SHORT);
            return;
        } else {
            if(BA.isEnabled()){
               BA.disable();

                IntentFilter BTIntent = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
                registerReceiver(BRPower, BTIntent);
                powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.startButton));
                isStarted = false;
                ToastMain("Service Stopped", Toast.LENGTH_SHORT);
                return;
            } else {
                powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.stopButton));
                isStarted = true;
                ToastMain("Could not stop service!", Toast.LENGTH_SHORT);
                return;
            }
        }
    }

    private void resetLoop(){
        final Handler resetLoopHandler = new Handler();
        resetLoopHandler.post(new Runnable(){
            @Override
            public void run(){
                if(isStarted) {
                    startScan();
                    resetLoopHandler.postDelayed(this, RESET_DELAY_MILLISECONDS);
                }
            }
        });
    }

    private void updateLoop(){
        final Handler updateLoopHandler = new Handler();
        updateLoopHandler.post(new Runnable(){
            @Override
            public void run(){
                if(fetchUserData()) {
                    reformEncounterLayout();
                }
                updateLoopHandler.postDelayed(this, UPDATE_DELAY_MILLISECONDS);
            }
        });
    }

    private void reformEncounterLayout(){
        LinearLayout encountersLayout = findViewById(R.id.Encounters_Scroll_Layout);
        encountersLayout.removeAllViews();

        TextView no_encounter = findViewById(R.id.No_EncounterTV);
        if(encounters.size() == 0){
            no_encounter.setText(R.string.no_encounter_txt);
            return;
        }else{
            no_encounter.setText(null);
        }

        for (int i = 0; i < encounters.size(); i++) {
            LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
            View v = inflater.inflate(R.layout.encounter_layout, null);
            TextView encounterInfo = v.findViewById(R.id.encounterInfo);
            encounterInfo.setText(encounters.get(i));
            if(encounters.get(i).contains("positive"))
                encounterInfo.setTextColor(getResources().getColorStateList(R.color.stopButton));
            encountersLayout.addView(v);
        }
    }

    public void startVisibility(){
        Log.d(TAG, "startVisibility: Starting Discoverability for 300s");

        Intent visibleIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        visibleIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);
        startActivity(visibleIntent);

        IntentFilter intentFilter = new IntentFilter(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(BRVisible, intentFilter);
    }

    public void startScan(){
        Log.d(TAG, "startScan: Starting Bluetooth Device Scan");

        if(BA.isDiscovering()){
            Log.d(TAG, "startScan: Was Already Scanning. Stopping Scan");
            BA.cancelDiscovery();
        }

        checkPermissions();

        BA.startDiscovery();

        IntentFilter scanIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(BRScan, scanIntent);
    }

    private void checkPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){

            int permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {

                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        }else{
            Log.d(TAG, "checkPermissions: Android Version Does Not Require Permissions");
        }
    }

    private void startMainActivity(){
        setContentView(R.layout.activity_main);

        powerBT = findViewById(R.id.BTPowerButton);
        powerBT.setBackgroundTintList(getResources().getColorStateList(R.color.startButton));

        powerBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                powerBluetooth();
            }
        });

        updateLoop();
    }

    private void startLoginActivity(){
        setContentView(R.layout.login_layout);

        Button loginscreen_login = findViewById(R.id.loginscreen_login);
        Button loginscreen_register = findViewById(R.id.loginscreen_register);

        login_error = findViewById(R.id.login_error);
        login_error.setText(null);

        loginscreen_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        loginscreen_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRegisterActivity();
            }
        });
    }

    private void startRegisterActivity(){
        setContentView(R.layout.register_layout);

        Button registerscreen_register = findViewById(R.id.registerscreen_register);
        Button registerscreen_login = findViewById(R.id.registerscreen_login);

        register_error = findViewById(R.id.register_error);
        register_error.setText(null);

        registerscreen_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
        registerscreen_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLoginActivity();
            }
        });
    }

    private boolean fetchUserData(){
        encounters.clear();

        TCPClient c = new TCPClient();
        String serverFeedback = c.sendServer("login_" + getSavedPhoneNumber());
        if(serverFeedback.equals("ERROR")){
            return false;
        }

        String[] userData = serverFeedback.split("_");
        ID = userData[0];

        Date d = new Date();
        int curDate = (int)(d.getTime() / (24 * 60 * 60 * 1000));

        for (int i = 1; i < userData.length; i = i + 3) {
            encounters.add("You encountered user of ID: " + userData[i] +
                    "\nCurrent known Covid-19 status: " + userData[i + 2] +
                    "\n" + (curDate - Integer.parseInt(userData[i + 1])) + " days ago");
        }

        return true;
    }


    private boolean registerEncounter(String encounteredUserID){
        TCPClient c = new TCPClient();
        String serverFeedback = c.sendServer("addencounter_" + getSavedPhoneNumber() + "_" + encounteredUserID);
        return serverFeedback.equals("OK");
    }

    private void ToastMain(String text, int Length){
        Toast.makeText(this, text, Length).show();
    }

    private boolean setSavedPhoneNumber(String phoneNB){
        SharedPreferences.Editor e = sp.edit();
        e.putString("phoneNB", phoneNB);
        return e.commit();
    }

    private String getSavedPhoneNumber(){
        return sp.getString("phoneNB",null);
    }

    private void login(){
        login_error.setText(null);
        if(((EditText)findViewById(R.id.login_phone_nb)).getText().toString().equals("")){
            login_error.setText(R.string.check_entry_error_txt);
            return;
        }

        TCPClient c = new TCPClient();
        String loginFeedback = c.sendServer("login_" + ((EditText)findViewById(R.id.login_phone_nb)).getText().toString());
        if(!loginFeedback.equals("ERROR") && setSavedPhoneNumber(((EditText)findViewById(R.id.login_phone_nb)).getText().toString())){
            encounters.clear();
            String[] userData = loginFeedback.split("_");
            ID = userData[0];

            Date d = new Date();
            int curDate = (int)(d.getTime() / (24 * 60 * 60 * 1000));

            for (int i = 1; i < userData.length; i = i + 3) {
                encounters.add("You encountered user of ID: " + userData[i] +
                        "\nCurrent known Covid-19 status: " + userData[i + 2] +
                        "\n" + (curDate - Integer.parseInt(userData[i + 1])) + " days ago");
            }
            startMainActivity();
        }else{
            login_error.setText(R.string.login_error_txt);
        }
    }
    private void register(){
        register_error.setText(null);
        if(((EditText)findViewById(R.id.register_first_name)).getText().toString().equals("")
                || ((EditText)findViewById(R.id.register_last_name)).getText().toString().equals("")
                || ((EditText)findViewById(R.id.register_phone_nb)).getText().toString().equals("")){
            register_error.setText(R.string.check_entry_error_txt);
            return;
        }

        TCPClient c = new TCPClient();
        String registerFeedback = c.sendServer("register_" + ((EditText)findViewById(R.id.register_first_name)).getText().toString()+"_"+
                ((EditText)findViewById(R.id.register_last_name)).getText().toString()+"_"+
                ((EditText)findViewById(R.id.register_phone_nb)).getText().toString());
        if(registerFeedback.equals("OK") && setSavedPhoneNumber(((EditText)findViewById(R.id.register_phone_nb)).getText().toString())){
            if(fetchUserData()) {
                startMainActivity();
            } else {
                register_error.setText(R.string.login_error_txt);
            }
        }else{
            register_error.setText(R.string.register_error_txt);
        }
    }
}
