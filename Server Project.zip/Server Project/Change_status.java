import java.io.File;
import java.io.IOException;

import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Change_status {
	
	public static void main (String[] args) {
		
		Scanner sc= new Scanner(System.in);  
		System.out.print("Format = phoneNB_status (ex: +961712345678_positive):\n");  
		String s = sc.nextLine();  	
		
		change_status_with_phonenumber(s.split("_")[0], s.split("_")[1]);
	}	
	
	
	
	public static void change_status_with_phonenumber(String phonenumber, String status) {
		String folderpath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";
		
		try {
			
		Find_file ff = new Find_file();
		String filepath = ff.find_file_with_phonenumber(phonenumber, folderpath);
		
		
		File xmlFile = new File(filepath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		Document doc = dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();
		
		
		NodeList idList = doc.getElementsByTagName("Covid_19");
		for (int k = 0; k < idList.getLength(); k++) {
			Node node1 = idList.item(k);
			if (node1.getNodeType() == Node.ELEMENT_NODE) {
				Element element = (Element) node1;
				element.setAttribute("current_known_status", status);
			}
		}
		
		
		
		
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        DOMSource source = new DOMSource(doc);
        StreamResult file = new StreamResult(new File(filepath));
        
        transformer.transform(source, file);
		
		System.out.println("Status updated");
	
		
		
		}catch (SAXException | ParserConfigurationException | IOException|TransformerException  e1) {
			e1.printStackTrace();
		}	
	}

}
