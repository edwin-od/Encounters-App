import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class Create_new_user_file {



	public static boolean createnewuser(String id, String firstName, String lastName, String phoneNumber) {

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		String folderpath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";
		try {

			File folder = new File(folderpath);
			File[] listOfFiles = folder.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].getName().contains(phoneNumber)) {
					return false;

				}
			}

			String xmlfilepath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files\\" + String.valueOf(id) + "_"
					+ phoneNumber + ".xml";
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();

			// add elements to document
			Element rootElement = doc.createElement("User_info");
			doc.appendChild(rootElement);

			// for output to file, console
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			// for pretty print
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);

			Element user = doc.createElement("User");
			user.setAttribute("id", id);

			rootElement.appendChild(createUserElement(doc, user, id, firstName, lastName, phoneNumber));

			Element encounters = doc.createElement("Encounters");
			rootElement.appendChild(encounters);
			Element covid_19 = doc.createElement("Covid_19");
			rootElement.appendChild(covid_19);
			covid_19.setAttribute("current_known_status", "negative");
			StreamResult console = new StreamResult(System.out);
			StreamResult file = new StreamResult(new File(xmlfilepath));
			transformer.transform(source, file);

		} catch (Exception e) {
			return false;
		}

		return true;

	}

	public static Node createUserElement(Document doc, Element elt, String id, String firstName, String lastName,
			String phoneNumber) {

		// create firstname element
		elt.appendChild(createUserElements(doc, elt, "firstname", firstName));

		// create lastname element
		elt.appendChild(createUserElements(doc, elt, "lastName", lastName));

		// create phone number element
		elt.appendChild(createUserElements(doc, elt, "phone_number", phoneNumber));

		return elt;

	}

	public static Node createUserElements(Document doc, Element element, String name, String value) {
		Element node = doc.createElement(name);
		node.appendChild(doc.createTextNode(value));
		return node;
	}
}
