import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
	private static int taskNumber = 1;
	private Socket connectionSocket;

	public ClientHandler(Socket connectionSocket) {
		this.connectionSocket = connectionSocket;
	}

	public void run() {
		try {
			String line, modifiedLine;
			modifiedLine = "an error occured please try again";
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			line = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())).readLine();
			String[] arrOfStr = line.split("_");
			System.out.println("Received: " + line);

			if (arrOfStr[0].equals("register")) {


				String Firstname = arrOfStr[1];
				String Lastname = arrOfStr[2];
				String PhoneNumber = arrOfStr[3];
				
				Find_id fi = new Find_id();
				String unique_id = fi.get_id();

				Create_new_user_file cnu = new Create_new_user_file();
				boolean success = cnu.createnewuser(unique_id, Firstname, Lastname, PhoneNumber);

				if (success) {
					modifiedLine = "OK";
					fi.increment_id();
					
					
				} else {

					modifiedLine = "ERROR";
				}
			}

			else if (arrOfStr[0].equals("addencounter")) {

				String PhoneNumber = arrOfStr[1];
				String encountered_id = arrOfStr[2];
				String folderpath ="C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";
				Find_file ff = new Find_file();
				String test = ff.find_file_with_ID(encountered_id ,folderpath);
				
                if ( test != null) {
					add_an_encounter add_encounter = new add_an_encounter();
					add_encounter.add_new_encounter(PhoneNumber, encountered_id);

					modifiedLine = "OK";
                }
                else {
                	modifiedLine ="ERROR";
                }

			}
			else if (arrOfStr[0].equals("login")) {
				String phonenumber = arrOfStr[1];
				
				retrieve_info ri =new retrieve_info();
				String retrieved_info = ri.retrieve_info_with_phonenumber(phonenumber);
				if (retrieved_info == null) {
					modifiedLine = ("ERROR");
				}
				else {
					modifiedLine = retrieved_info ; 
				}
				
			}
			else {
				modifiedLine =("ERROR");
			}

			outToClient.writeBytes(modifiedLine);
			System.out.println("Sent: "+modifiedLine);

			// Terminate the connection
			connectionSocket.close();
			outToClient.close();
		} catch (Exception e) {
		}

	}
}
