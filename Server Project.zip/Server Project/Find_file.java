import java.io.File;

public class Find_file {


	public static String find_file_with_ID(String ID, String folderpath) {

		String filepath, f;

		File folder = new File(folderpath);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			String[] arrOfStr = listOfFiles[i].getName().split("_");
			if (arrOfStr[0].equals(ID)) {
				f = listOfFiles[i].getName();
				filepath = folderpath + "\\" + f;
				return filepath;

			}
		}

		return null;
	}

	public static String find_file_with_phonenumber(String phonenumber, String folderpath) {
		String filepath, f;

		File folder = new File(folderpath);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			String[] arrOfStr = listOfFiles[i].getName().split("_");
			if (arrOfStr[1].equals(phonenumber + ".xml")) {
				f = listOfFiles[i].getName();
				filepath = folderpath + "\\" + f;


				return filepath;
			}
		}
		return null;
	}
}
