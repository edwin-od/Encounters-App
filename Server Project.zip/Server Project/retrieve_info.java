import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class retrieve_info {

	

	public static String retrieve_info_with_phonenumber(String phonenumber) {
		String user_data = null;

		try {

			String folderpath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";

			Find_file ff = new Find_file();
			String filepath = ff.find_file_with_phonenumber(phonenumber, folderpath);
			if (filepath ==null) {
				return null;
			}
			File xmlFile = new File(filepath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			Element root = doc.getDocumentElement();
			ArrayList<String> info_list = new ArrayList<String>();

			NodeList idList = doc.getElementsByTagName("User");
			for (int k = 0; k < idList.getLength(); k++) {
				Node node1 = idList.item(k);
				if (node1.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node1;
					info_list.add(element.getAttribute("id"));
					break;
				}
			}

			NodeList nList = doc.getElementsByTagName("Encounter");
			Date d = new Date();
			int current_Date = (int) (d.getTime() / (24 * 60 * 60 * 1000));
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node node = nList.item(temp);
				if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName().equals("Encounter")) {
					Element element = (Element) node;
					
					int date2 = Integer.parseInt(element.getElementsByTagName("date").item(0).getTextContent());
					
					if(current_Date - date2 < 15) {
					
						String encountered_id =element.getElementsByTagName("encountered_user_ID").item(0).getTextContent();						
						
						info_list.add(encountered_id);
						info_list.add(element.getElementsByTagName("date").item(0).getTextContent());
						info_list.add(retrieve_status_of_encountered_id(encountered_id));
					}
				}
			}

			user_data = info_list.get(0);

			for (int j = 1; j < info_list.size(); j++) {

				user_data += "_" + info_list.get(j);

			}

		} catch (SAXException | ParserConfigurationException | IOException e1) {
			e1.printStackTrace();
		}
		return user_data;
	}

	public static String retrieve_status_of_encountered_id(String id) {
		String folderpath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";
		String status= null;
		try {
			Find_file ff2 = new Find_file();
			String filepath = ff2.find_file_with_ID(id, folderpath);
			if (filepath.equals(null)) {
				return null;
			}
			File xmlFile2 = new File(filepath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document doc2 = dBuilder.parse(xmlFile2);
			doc2.getDocumentElement().normalize();
			Element root2 = doc2.getDocumentElement();
			NodeList statusList = doc2.getElementsByTagName("Covid_19");
			for (int k = 0; k < statusList.getLength(); k++) {
				Node node2 = statusList.item(k);
				if (node2.getNodeType() == Node.ELEMENT_NODE) {
					Element element2 = (Element) node2;					
					status = element2.getAttribute("current_known_status");
				}
			}
			
			
			
		
			
		
		}catch (SAXException | ParserConfigurationException | IOException e1) {
			e1.printStackTrace();
		}
		return status;
	}

}