import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Find_id {
	
	
	public static String get_id() {
		String id = null;
		try {
			String filepath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files\\ffff.xml";
			File xmlFile = new File(filepath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
		   
			Element root = doc.getDocumentElement();
			NodeList nList = doc.getElementsByTagName("id");


			for (int i= 0; i< nList.getLength(); i++) {
				
				
				Node nNode = nList.item(i);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {



					Element eElement = (Element) nNode;
					id =eElement.getAttribute("id_nmbr");
					int int_id = Integer.parseInt(id);
					
			
				}
			}
			
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			StreamResult result = new StreamResult(new File(filepath));
			StreamResult console = new StreamResult(System.out);
			transformer.transform(source, result);
			
        
	}catch (SAXException | ParserConfigurationException | IOException  |TransformerException   e1) {
        e1.printStackTrace();
    }
		return id;
		
	}
	
	
	public static void increment_id(){
		String id = null;
try {
		String filepath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files\\ffff.xml";
		File xmlFile = new File(filepath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
       
        Element root = doc.getDocumentElement();
        NodeList nList = doc.getElementsByTagName("id");

        for (int i= 0; i< nList.getLength(); i++) {
        	
        	
            Node nNode = nList.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {



                Element eElement = (Element) nNode;
                id =eElement.getAttribute("id_nmbr");
                int int_id = Integer.parseInt(id);
                
                int_id++;

                   
                    eElement.setAttribute("id_nmbr",String.valueOf(int_id));
		
            }
        }
		
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		StreamResult result = new StreamResult(new File(filepath));
		StreamResult console = new StreamResult(System.out);
		transformer.transform(source, result);
		
        
	}catch (SAXException | ParserConfigurationException | IOException  |TransformerException   e1) {
        e1.printStackTrace();
    }
	
		
		
	}
}
