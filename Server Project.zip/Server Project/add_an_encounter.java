import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class add_an_encounter {	
	
	public static void add_new_encounter(String phonenumber,String encountered_id) {
		
		String folderpath = "C:\\Users\\claud\\Desktop\\Project networks\\XML_Files";
		
		try {
			
		Find_file find_file = new Find_file();
		String filepath = find_file.find_file_with_phonenumber(phonenumber, folderpath); 
		
		//Delete old encounters with this id
		deleteEncounter(filepath, encountered_id);
		
		//System.out.println(filepath);
		File xmlFile = new File(filepath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.parse(xmlFile);
        
        Node encounters = doc.getElementsByTagName("Encounters").item(0);
        Element encounter =doc.createElement("Encounter");
	    encounters.appendChild(encounter);
	    
	    Element encounteredwith = doc.createElement("encountered_user_ID");
        encounteredwith.appendChild(doc.createTextNode(encountered_id));
        encounter.appendChild(encounteredwith);
        
        
    	Date d = new Date();
    	int current_Date =(int)(d.getTime()/(24*60*60*1000));
        
        Element date_of_encounter = doc.createElement("date");
        date_of_encounter.appendChild(doc.createTextNode(String.valueOf(current_Date)));
        encounter.appendChild(date_of_encounter);
	    
	    
        
        
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        DOMSource source = new DOMSource(doc);
        StreamResult console = new StreamResult(System.out);
        StreamResult file = new StreamResult(new File(filepath));
        
        transformer.transform(source, file);
        
        
		
		
	}catch (SAXException | ParserConfigurationException | IOException |TransformerException  e1) {
        e1.printStackTrace();
    }
	
	}
	
	public static void deleteEncounter(String path, String encounteredID){
		
		try{
			File xmlFile2 = new File(path);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document doc2 = dBuilder.parse(xmlFile2);
			doc2.getDocumentElement().normalize();
			Element root2 = doc2.getDocumentElement();
			for(int i= 0; i < doc2.getElementsByTagName("Encounters").item(0).getChildNodes().getLength(); i++){
				NodeList nList = doc2.getElementsByTagName("Encounters").item(0).getChildNodes();		
								
				if(nList.item(i).getNodeType() == Node.ELEMENT_NODE && nList.item(i).getNodeName().equals("Encounter")){
					NodeList encInf = nList.item(i).getChildNodes();
					for (int j = 0; j < encInf.getLength(); j++){
						if(encInf.item(j).getNodeType() == Node.ELEMENT_NODE && encInf.item(j).getNodeName().equals("encountered_user_ID")){
							if(encInf.item(j).getTextContent().equals(encounteredID)){
								doc2.getElementsByTagName("Encounters").item(0).removeChild(nList.item(i));
							}
						}
					}
				}
			}
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc2);
			StreamResult console = new StreamResult(System.out);
			StreamResult file = new StreamResult(new File(path));
			
			transformer.transform(source, file);
		}catch(Exception e){
		}
		
	}

}
