import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class TCP_server {

	public static void main(String[] args) throws Exception {
		ServerSocket welcomeSocket = new ServerSocket(6789);
		Socket connectionSocket;
		ExecutorService executor = Executors.newCachedThreadPool();
		while (true) {
			// Waiting for initial contact
			System.out.println("--- Waiting for user ---");
			connectionSocket = welcomeSocket.accept();
			System.out.println("Connected to: " + connectionSocket.getInetAddress());

			// Spawn a new thread devoted to the client
			// Let the thread handle the client
			ClientHandler ch = new ClientHandler(connectionSocket);
			executor.execute(ch);

		}
	}
}